module.exports = {
    plugins: {
        autoprefixer: {}
    }
};
